import Footer from "@/Components/Footer";
import Navbar from "@/Components/Navbar";
import { Head } from "@inertiajs/react";

const TentangKami = () => {
    return (
        <>
            <Head title="Informasi Umum" />
            <Navbar />
            <div className="p-8 mt-12 container mx-auto">
                <h1 className="text-4xl font-bold mb-6">Tentang Kami</h1>
                <p className="mb-8">
                    Suku Dinas Pendidikan Wilayah II Kota Administrasi Jakarta
                    Pusat bertugas memastikan pendidikan berkualitas dan
                    inklusif untuk semua siswa, termasuk mereka yang memiliki
                    kebutuhan khusus. Kami berkomitmen untuk menyediakan
                    informasi berbagai program dan layanan untuk mendukung
                    keberhasilan akademis siswa disabilitas.
                </p>

                <div className="divider"></div>

                <div className="mb-8">
                    <h2 className="text-2xl font-semibold mb-4">
                        Visi dan Misi
                    </h2>
                    <div className="flex flex-col lg:flex-row lg:items-start lg:space-x-8">
                        <div className="lg:w-1/2 mb-4 lg:mb-0">
                            <h3 className="text-lg font-semibold mb-2">Visi</h3>
                            <p>
                                Menciptakan pendidikan inklusif yang berkualitas
                                bagi semua siswa.
                            </p>

                            <h3 className="text-lg font-semibold mb-2 mt-4">
                                Misi
                            </h3>
                            <ul className="list-disc list-inside">
                                <li>
                                    Mewujudkan pendidikan yang inklusif dan
                                    berkualitas untuk semua siswa di Suku Dinas
                                    Pendidikan Wilayah II Kota administrasi
                                    Jakarta Pusat.
                                </li>
                            </ul>

                            <h3 className="text-lg font-semibold mb-2 mt-4">
                                Tujuan
                            </h3>
                            <ul className="list-disc list-inside">
                                <li>
                                    Menyediakan akses pendidikan yang adil dan
                                    sumber daya yang diperlukan untuk mendukung
                                    siswa dengan disabilitas dalam mencapai
                                    potensi penuh mereka
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
};

export default TentangKami;
