import Footer from "@/Components/Footer";
import Navbar from "@/Components/Navbar";
import { Head } from "@inertiajs/react";
import React from "react";

const PanduanDanBuku = () => {
    return (
        <>
            <Head title="Panduan dan Buku" />
            <Navbar />
            <div className="container mx-auto px-4 py-8 flex-grow my-12">
                <h1 className="text-4xl font-bold">Panduan dan Buku</h1>
                <div className="divider mb-6"></div>

                {/* Section for Panduan */}
                <section className="mb-12">
                    <h2 className="text-3xl font-semibold mb-4">Panduan</h2>
                    <div className="border rounded-lg p-4 flex flex-col sm:flex-row items-center">
                        <img
                            src="https://placehold.co/320x400"
                            alt="Panduan Thumbnail"
                            className="w-32 h-40 object-cover rounded-lg mb-4 sm:mb-0 sm:mr-6"
                        />
                        <div>
                            <p className="mb-2 font-semibold">
                                Panduan Pengguna Sistem
                            </p>
                            <p className="mb-4 text-primary-content">
                                Panduan lengkap untuk pengguna sistem, mencakup
                                langkah-langkah untuk memulai dan tips untuk
                                menggunakan fitur-fitur utama.
                            </p>
                            <a
                                href="#"
                                className="btn btn-primary"
                                download="Panduan_Pengguna_Sistem.pdf"
                            >
                                Unduh Panduan
                            </a>
                        </div>
                    </div>
                </section>

                {/* Section for Buku */}
                <section>
                    <h2 className="text-3xl font-semibold mb-4">Buku</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {Array.from({ length: 6 }).map((_, index) => (
                            <div
                                key={index}
                                className="border rounded-lg p-4 flex flex-col items-center"
                            >
                                <img
                                    src="https://placehold.co/320x400"
                                    alt={`Buku ${index + 1} Thumbnail`}
                                    className="w-32 h-40 object-cover rounded-lg mb-4"
                                />
                                <div className="text-center">
                                    <p className="mb-2 font-semibold">
                                        Buku {index + 1}: Judul Buku {index + 1}
                                    </p>
                                    <p className="mb-4 text-primary-content">
                                        Deskripsi singkat tentang Buku{" "}
                                        {index + 1}, memberikan gambaran umum
                                        tentang isi dan manfaat buku ini bagi
                                        pembaca.
                                    </p>
                                    <a
                                        href="#"
                                        className="btn btn-primary"
                                        download={`Buku_${index + 1}.pdf`}
                                    >
                                        Unduh Buku
                                    </a>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>
            </div>
            <Footer />
        </>
    );
};

export default PanduanDanBuku;
