import { Head } from "@inertiajs/react";
import Footer from "@/Components/Footer";
import Navbar from "@/Components/Navbar";

const RegistrationInfo = () => {
    return (
        <>
            <Navbar />
            <div className="flex flex-col min-h-screen">
                <main className="flex-grow bg-base-200 py-12 px-4">
                    <Head title="Informasi Pendaftaran" />
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-10 w-full max-w-screen-xl mx-auto pt-16">
                        {/* PAUD Information Card */}
                        <div className="relative bg-white shadow-lg rounded-lg p-6 border-t-8 border-yellow-400">
                            <div className="absolute inset-x-0 top-0 h-[6px] bg-gradient-to-r from-red-500 via-yellow-400 to-blue-500"></div>
                            <div className="card-body pt-6">
                                <h2 className="text-2xl font-bold mb-4 text-yellow-400">
                                    PAUD (Pendidikan Anak Usia Dini)
                                </h2>
                                <p className="mb-4">
                                    Untuk mendaftar ke PAUD (Pendidikan Anak
                                    Usia Dini), berikut langkah-langkah yang
                                    perlu diikuti:
                                </p>
                                <ul className="list-disc pl-5 mb-4">
                                    <li>
                                        Siapkan dokumen kelahiran anak dan bukti
                                        tempat tinggal.
                                    </li>
                                    <li>
                                        Kunjungi PAUD terdekat untuk mendapatkan
                                        formulir pendaftaran.
                                    </li>
                                    <li>
                                        Isi formulir pendaftaran dan lengkapi
                                        dengan dokumen yang dibutuhkan.
                                    </li>
                                    <li>
                                        Hadiri sesi orientasi yang mungkin
                                        diperlukan.
                                    </li>
                                </ul>
                                <p>
                                    Untuk informasi lebih lanjut, hubungi PAUD
                                    setempat atau kunjungi situs web resmi
                                    mereka.
                                </p>
                            </div>
                        </div>

                        {/* SKB Information Card */}
                        <div className="relative bg-white shadow-lg rounded-lg p-6 border-t-8 border-green-600">
                            <div className="absolute inset-x-0 top-0 h-[6px] bg-gradient-to-r from-green-600 via-blue-500 to-yellow-500"></div>
                            <div className="card-body pt-6">
                                <h2 className="text-2xl font-bold mb-4 text-green-600">
                                    SKB (Sanggar Kegiatan Belajar)
                                </h2>
                                <p className="mb-4">
                                    Untuk mendaftar ke SKB (Sanggar Kegiatan
                                    Belajar), ikuti petunjuk berikut:
                                </p>
                                <ul className="list-disc pl-5 mb-4">
                                    <li>
                                        Siapkan dokumen pendaftaran yang
                                        diperlukan.
                                    </li>
                                    <li>
                                        Kunjungi kantor SKB atau situs web
                                        mereka untuk mendapatkan formulir
                                        pendaftaran.
                                    </li>
                                    <li>
                                        Isi formulir dengan informasi yang
                                        diperlukan dan lengkapi dengan dokumen
                                        yang dibutuhkan.
                                    </li>
                                    <li>
                                        Kirimkan formulir ke kantor SKB atau
                                        melalui portal online mereka.
                                    </li>
                                </ul>
                                <p>
                                    Hubungi SKB langsung atau kunjungi situs web
                                    mereka untuk bantuan lebih lanjut.
                                </p>
                            </div>
                        </div>

                        {/* SD Information Card */}
                        <div className="relative bg-white shadow-lg rounded-lg p-6 border-t-8 border-red-700">
                            <div className="absolute inset-x-0 top-0 h-[6px] bg-gradient-to-r from-red-400 via-orange-300 to-red-500"></div>
                            <div className="card-body pt-6">
                                <h2 className="text-2xl font-bold mb-4 text-red-500">
                                    SD (Sekolah Dasar)
                                </h2>
                                <p>
                                    Untuk mendaftar ke SD (Sekolah Dasar), Anda
                                    perlu mengikuti langkah-langkah berikut:
                                </p>
                                <ul className="list-disc pl-5">
                                    <li>
                                        Siapkan dokumen yang diperlukan seperti
                                        akta kelahiran dan bukti tempat tinggal.
                                    </li>
                                    <li>
                                        Kunjungi kantor pendidikan setempat
                                        untuk mendapatkan formulir pendaftaran.
                                    </li>
                                    <li>
                                        Isi formulir dengan data yang diperlukan
                                        dan kirimkan bersama dokumen yang
                                        dibutuhkan.
                                    </li>
                                    <li>
                                        Hadiri sesi orientasi jika diperlukan.
                                    </li>
                                </ul>
                                <p>
                                    Untuk informasi lebih lanjut, silakan
                                    hubungi sekolah SD terdekat atau kunjungi
                                    situs web resmi mereka.
                                </p>
                            </div>
                        </div>

                        {/* SMP Information Card */}
                        <div className="relative bg-white shadow-lg rounded-lg p-6 border-t-8 border-blue-800">
                            <div className="absolute inset-x-0 top-0 h-[6px] bg-gradient-to-r from-blue-600 via-sky-500 to-blue-500"></div>
                            <div className="card-body pt-6">
                                <h2 className="text-2xl font-bold mb-4 text-blue-800">
                                    SMP (Sekolah Menengah Pertama)
                                </h2>
                                <p>
                                    Untuk mendaftar ke SMP (Sekolah Menengah
                                    Pertama), harap ikuti petunjuk berikut:
                                </p>
                                <ul className="list-disc pl-5">
                                    <li>
                                        Siapkan raport siswa dari sekolah dasar.
                                    </li>
                                    <li>
                                        Dapatkan formulir pendaftaran dari
                                        kantor SMP atau unduh secara online.
                                    </li>
                                    <li>
                                        Isi formulir dengan data yang diperlukan
                                        dan lampirkan dokumen yang diperlukan.
                                    </li>
                                    <li>
                                        Kirim formulir ke kantor SMP atau
                                        melalui portal online mereka.
                                    </li>
                                </ul>
                                <p>
                                    Hubungi SMP langsung atau kunjungi situs web
                                    mereka untuk bantuan lebih lanjut.
                                </p>
                            </div>
                        </div>

                        {/* SMA Information Card */}
                        <div className="relative bg-white shadow-lg rounded-lg p-6 border-t-8 border-sky-300">
                            <div className="absolute inset-x-0 top-0 h-[6px] bg-gradient-to-r from-blue-400 via-sky-500 to-blue-200"></div>
                            <div className="card-body pt-6">
                                <h2 className="text-2xl font-bold mb-4 text-gray-700">
                                    SMA (Sekolah Menengah Atas)
                                </h2>
                                <p>
                                    Untuk mendaftar ke SMA (Sekolah Menengah
                                    Atas), ikuti langkah-langkah berikut:
                                </p>
                                <ul className="list-disc pl-5">
                                    <li>
                                        Siapkan transkrip nilai SMP Anda dan
                                        dokumen relevan lainnya.
                                    </li>
                                    <li>
                                        Dapatkan formulir pendaftaran dari
                                        kantor SMA atau unduh dari situs web
                                        mereka.
                                    </li>
                                    <li>
                                        Isi formulir dan kirim bersama dokumen
                                        yang diperlukan, baik secara online atau
                                        langsung.
                                    </li>
                                    <li>
                                        Ikuti tes masuk atau wawancara yang
                                        diperlukan.
                                    </li>
                                </ul>
                                <p>
                                    Untuk informasi tambahan, hubungi kantor SMA
                                    atau periksa situs web resmi mereka.
                                </p>
                            </div>
                        </div>

                        {/* SMK Information Card */}
                        <div className="relative bg-white shadow-lg rounded-lg p-6 border-t-8 border-gray-500">
                            <div className="absolute inset-x-0 top-0 h-[6px] bg-gradient-to-r from-gray-200 via-sky-200 to-gray-300"></div>
                            <div className="card-body pt-6">
                                <h2 className="text-2xl font-bold mb-4 text-gray-500">
                                    SMK (Sekolah Menengah Kejuruan)
                                </h2>
                                <p>
                                    Untuk mendaftar ke SMK (Sekolah Menengah
                                    Kejuruan), Anda harus:
                                </p>
                                <ul className="list-disc pl-5">
                                    <li>
                                        Siapkan ijazah sekolah menengah dan
                                        sertifikasi kejuruan yang relevan.
                                    </li>
                                    <li>
                                        Kunjungi kantor SMK atau situs web
                                        mereka untuk mendapatkan formulir
                                        pendaftaran.
                                    </li>
                                    <li>
                                        Isi formulir dengan informasi pribadi
                                        dan akademis Anda.
                                    </li>
                                    <li>
                                        Kirimkan formulir bersama dokumen Anda
                                        di kantor SMK atau online.
                                    </li>
                                </ul>
                                <p>
                                    Untuk informasi lebih lanjut, hubungi SMK
                                    atau kunjungi situs resmi mereka.
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Divider Line */}
                    <div className="w-full h-0.5 my-16 bg-gradient-to-r from-teal-400 via-green-500 to-yellow-500"></div>

                    {/* Bantuan Keuangan Section */}
                    <div className="bg-white shadow-lg rounded-lg p-8 max-w-screen-xl mx-auto">
                        <h2 className="text-3xl font-bold mb-6 text-teal-600">
                            Bantuan Keuangan
                        </h2>
                        <p className="text-lg mb-4">
                            Untuk mendukung pendidikan, tersedia berbagai
                            program beasiswa dan bantuan keuangan. Beberapa
                            langkah yang bisa Anda ambil untuk mendapatkan
                            bantuan ini adalah:
                        </p>
                        <ul className="list-disc pl-6 text-lg">
                            <li>
                                Cari informasi tentang beasiswa yang tersedia di
                                sekolah atau perguruan tinggi yang ingin Anda
                                masuki.
                            </li>
                            <li>
                                Kunjungi situs web resmi untuk mengetahui syarat
                                dan ketentuan yang harus dipenuhi.
                            </li>
                            <li>
                                Siapkan dokumen yang diperlukan, seperti
                                transkrip nilai, surat rekomendasi, dan esai
                                pribadi.
                            </li>
                            <li>
                                Ajukan aplikasi sesuai dengan prosedur yang
                                ditentukan.
                            </li>
                            <li>
                                Pertimbangkan bantuan keuangan tambahan yang
                                mungkin tersedia melalui pemerintah atau
                                organisasi non-profit.
                            </li>
                        </ul>
                        <p className="text-lg mt-6">
                            Untuk informasi lebih lanjut, Anda dapat menghubungi
                            kantor administrasi keuangan sekolah atau lembaga
                            pendidikan yang bersangkutan.
                        </p>
                    </div>
                </main>
                <Footer className="bg-gray-800 text-white py-4" />
            </div>
        </>
    );
};

export default RegistrationInfo;
