import Footer from "@/Components/Footer";
import Hero from "@/Components/Hero";
import Navbar from "@/Components/Navbar";
import {
    Card,
    CardActions,
    CardBody,
    CardImage,
    CardTitle,
} from "@/Components/ui/Card";
import { Head } from "@inertiajs/react";
import React from "react";

const Homepage = () => {
    return (
        <>
            <Head title="Beranda" />
            <Navbar />
            {/* Hero Section */}
            <Hero />

            {/* Jumlah Sekolah Inklusif di Indonesia */}
            <div className="container mx-auto px-4 py-8 flex-grow my-12">
                <div className="text-center font-bold text-2xl md:text-3xl mt-12 text-primary">
                    Jumlah Sekolah Inklusif di Suku Dinas Jakarta Pusat II
                </div>
                <div className="stats stats-vertical lg:stats-horizontal shadow my-12 w-full bg-primary text-secondary-content">
                    <div className="stat">
                        <div className="stat-title">PAUD</div>
                        <div className="stat-value text-lg md:text-2xl">
                            31K
                        </div>
                        <div className="stat-desc">Lorem ipsum</div>
                    </div>

                    <div className="stat">
                        <div className="stat-title">SD</div>
                        <div className="stat-value text-lg md:text-2xl">
                            4,200
                        </div>
                        <div className="stat-desc">Lorem ipsum</div>
                    </div>

                    <div className="stat">
                        <div className="stat-title">SMP</div>
                        <div className="stat-value text-lg md:text-2xl">
                            1,200
                        </div>
                        <div className="stat-desc">Lorem ipsum</div>
                    </div>
                    <div className="stat">
                        <div className="stat-title">SMA</div>
                        <div className="stat-value text-lg md:text-2xl">
                            1,200
                        </div>
                        <div className="stat-desc">Lorem ipsum</div>
                    </div>
                    <div className="stat">
                        <div className="stat-title">SMK</div>
                        <div className="stat-value text-lg md:text-2xl">
                            1,200
                        </div>
                        <div className="stat-desc">Lorem ipsum</div>
                    </div>
                    <div className="stat">
                        <div className="stat-title">SKB</div>
                        <div className="stat-value text-lg md:text-2xl">
                            1,200
                        </div>
                        <div className="stat-desc">Lorem ipsum</div>
                    </div>
                </div>
            </div>

            {/* Post Cards Section */}
            <div className="container mx-auto px-4 py-8 flex-grow my-12">
                <div className="flex items-center justify-center h-12 md:h-20 font-bold text-2xl md:text-3xl mb-3 text-primary">
                    Post Terbaru Minggu Ini
                </div>
                <div className="container mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {Array.from({ length: 3 }).map((_, index) => (
                            <Card
                                className="card-compact bg-base-100 shadow-lg hover:shadow-2xl transition-shadow"
                                key={index}
                            >
                                <CardImage
                                    src={
                                        "Images/poster-hari-disabilitas-international.jpg"
                                    }
                                    alt={`Post ${index + 1}`}
                                    className="object-cover h-40 w-full"
                                />
                                <CardBody className="p-4">
                                    <CardTitle className="text-xl">
                                        Hari Nasional
                                    </CardTitle>
                                    <p className="text-sm">Date</p>
                                    <CardActions>
                                        <button className="btn btn-primary btn-sm">
                                            Read More
                                        </button>
                                    </CardActions>
                                </CardBody>
                            </Card>
                        ))}
                    </div>
                </div>
            </div>

            {/* Layanan Lainnya Section */}
            <div className="container mx-auto px-4 py-8 flex-grow my-12">
                <div className="flex items-center justify-center h-12 md:h-20 font-bold text-2xl md:text-3xl mb-3 text-primary">
                    Layanan Lainnya
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array.from({ length: 3 }).map((_, index) => (
                        <Card
                            className="card-compact bg-base-100 shadow-lg hover:scale-105 transition-transform"
                            key={index}
                        >
                            <CardImage
                                src={"svg/Pelayanan.svg"}
                                alt={`Layanan Publik ${index + 1}`}
                                className="object-cover h-40 w-full"
                            />
                            <CardBody className="p-4">
                                <CardTitle className="text-xl">
                                    Hari Nasional
                                </CardTitle>
                                <p className="text-sm">
                                    Brief description of the post goes here.
                                </p>
                                <CardActions className="justify-center">
                                    <a className="link link-primary" href="#">
                                        Read More
                                    </a>
                                </CardActions>
                            </CardBody>
                        </Card>
                    ))}
                </div>
            </div>

            {/* Program Disabilitas Section */}
            <div className="container mx-auto px-4 py-8 flex-grow my-12">
                <h2 className="text-2xl font-bold text-primary mb-6">
                    Program Disabilitas Sekolah
                </h2>
                <ul className="list-disc list-inside text-base-content text-sm md:text-base">
                    <li>
                        Summary of essential information for individuals with
                        special needs.
                    </li>
                    <li>
                        Guidance on accessing various services and resources.
                    </li>
                    <li>
                        Important contacts and resources available for support.
                    </li>
                </ul>
            </div>

            {/* Panduan dan Buku Section */}
            <div className="container mx-auto px-4 py-8 flex-grow my-12">
                <h2 className="text-2xl font-bold text-primary mb-6">
                    Panduan dan Buku
                </h2>
                <ul className="list-disc list-inside text-base-content text-sm md:text-base">
                    <li>Guidebook 1</li>
                    <li>Guidebook 2</li>
                    <li>Guidebook 3</li>
                    <li>Guidebook 4</li>
                    <li>Guidebook 5</li>
                </ul>
            </div>

            {/* Testimoni Section */}
            <div className="container mx-auto px-4 py-8 flex-grow my-12 ">
                <h2 className="text-2xl font-bold text-primary mb-6">
                    Testimoni
                </h2>
                <p className="text-base-content">
                    Testimonials from individuals who have benefited from the
                    services and programs.
                </p>
            </div>

            {/* Feedback & Saran Section */}
            <div className="container mx-auto px-4 py-8 flex-grow my-12">
                <h2 className="text-2xl font-bold text-primary mb-6">
                    Feedback & Saran
                </h2>
                <p className="text-base-content">
                    Provide your feedback and suggestions to help us improve our
                    services.
                </p>
            </div>

            <Footer />
        </>
    );
};

export default Homepage;
