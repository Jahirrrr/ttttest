import Footer from "@/Components/Footer";
import Navbar from "@/Components/Navbar";
import { Head } from "@inertiajs/react";
import { useState } from "react";

const Sekolah = () => {
    const [searchQuery, setSearchQuery] = useState("");

    const sekolahData = [
        {
            no: 1,
            nama: "SMPN 216",
            npsn: "20100237",
            alamat: "Jl. Salemba Raya No. 18",
            kecamatan: "Senen",
            telepon: "081314320000",
            email: "smpn216_jp@yahoo.co.id",
            website: "www.smpn216jkt.sch.id",
        },
        {
            no: 2,
            nama: "SMPN 10 Jakarta",
            npsn: "20100252",
            alamat: "Jalan Sumur Batu Raya",
            kecamatan: "Kemayoran",
            telepon: "085770833000",
            email: "[Not provided]",
            website: "[Not provided]",
        },
        {
            no: 3,
            nama: "SMP Negeri 28",
            npsn: "20100270",
            alamat: "Jln Mardani 17 Johar Baru",
            kecamatan: "Johar Baru",
            telepon: "0214246208",
            email: "smpnegeri28jakpus@gmail.com",
            website: "www.smpnegeri28jakarta.sch.id",
        },
        {
            no: 4,
            nama: "SMP Negeri 156 Jakarta",
            npsn: "20100230",
            alamat: "Jalan Kramat Pulo Gundul IV/4",
            kecamatan: "Johar Baru",
            telepon: "0214288910",
            email: "smpn156jp@gmail.com",
            website: "https://www.smpn156jkt.sch.id/",
        },
    ];

    // Filter the sekolahData based on the search query
    const filteredData = sekolahData.filter(
        (sekolah) =>
            sekolah.nama.toLowerCase().includes(searchQuery.toLowerCase()) ||
            sekolah.kecamatan
                .toLowerCase()
                .includes(searchQuery.toLowerCase()) ||
            sekolah.alamat.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="flex flex-col min-h-screen">
            <Head title="Daftar Sekolah" />
            <Navbar />
            <main className="container mx-auto px-4 py-8 flex-grow my-12">
                <h1 className="text-3xl font-bold mb-6">Daftar Sekolah</h1>

                {/* Search Bar */}
                <div className="mb-6">
                    <input
                        type="text"
                        className="input input-bordered w-full"
                        placeholder="Cari berdasarkan nama, kecamatan, atau alamat sekolah..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>

                <div className="overflow-x-auto">
                    <table className="table table-compact w-full">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Sekolah</th>
                                <th>NPSN</th>
                                <th>Alamat</th>
                                <th>Kecamatan</th>
                                <th>Telepon</th>
                                <th>Email</th>
                                <th>Website</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredData.length > 0 ? (
                                filteredData.map((sekolah) => (
                                    <tr key={sekolah.no}>
                                        <th>{sekolah.no}</th>
                                        <td>{sekolah.nama}</td>
                                        <td>{sekolah.npsn}</td>
                                        <td>{sekolah.alamat}</td>
                                        <td>{sekolah.kecamatan}</td>
                                        <td>{sekolah.telepon}</td>
                                        <td>{sekolah.email}</td>
                                        <td>{sekolah.website}</td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="8" className="text-center">
                                        Tidak ada sekolah yang cocok dengan
                                        pencarian Anda.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default Sekolah;
