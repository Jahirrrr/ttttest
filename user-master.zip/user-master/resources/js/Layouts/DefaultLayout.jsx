import Footer from "@/Components/Footer";
import Navbar from "@/Components/Navbar";
import React from "react";

export default function DefaultLayout({ children }) {
    return (
        <>
            <Navbar />
            <div className="container mx-auto px-4 py-8 flex-grow my-12">
                {children}
            </div>
            <Footer />
        </>
    );
}
