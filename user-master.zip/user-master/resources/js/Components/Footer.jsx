import React from "react";
import { FaFacebook, FaInstagram, FaXTwitter } from "react-icons/fa6";

const Footer = () => {
    return (
        <footer className="footer relative bg-secondary text-white py-8">
            <div className="absolute inset-x-0 top-0 h-[6px] bg-gradient-to-r from-teal-300 via-green-500 to-blue-700" />
            <div className="container mx-auto px-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full">
                    <div>
                        <h2 className="footer-title">
                            <a href={route("kontak")}>Kontak Kami</a>
                        </h2>

                        <p className="text-sm">Email: example@example.com</p>
                        <p className="text-sm">Phone: +123 456 7890</p>
                    </div>

                    <div className="grid-flow-col gap-4 md:place-self-center md:justify-self-end">
                        <h2 className="footer-title">Ikuti Kami</h2>
                        <div className="flex space-x-4">
                            <a
                                href="https://www.facebook.com"
                                target="_blank"
                                rel="noopener noreferrer"
                                aria-label="Facebook"
                                className="text-white hover:text-primary transition-transform transform hover:scale-110"
                            >
                                <FaFacebook className="h-6 w-6" />
                            </a>
                            <a
                                href="https://www.twitter.com"
                                target="_blank"
                                rel="noopener noreferrer"
                                aria-label="Twitter"
                                className="text-white hover:text-primary transition-transform transform hover:scale-110"
                            >
                                <FaXTwitter className="h-6 w-6" />
                            </a>
                            <a
                                href="https://www.instagram.com"
                                target="_blank"
                                rel="noopener noreferrer"
                                aria-label="Instagram"
                                className="text-white hover:text-primary transition-transform transform hover:scale-110"
                            >
                                <FaInstagram className="h-6 w-6" />
                            </a>
                        </div>
                    </div>
                </div>

                {/* Footer Bottom Section */}
                <div className="mt-8 text-center text-sm">
                    <p className="mt-4">
                        Hak Cipta Suku Dinas Pendidikan - Wilayah II Kota
                        Administrasi Jakarta Pusat &copy;{" "}
                        {new Date().getFullYear()}
                    </p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
