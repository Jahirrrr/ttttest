<?php

namespace App\Http\Controllers;

use App\Models\ProfilSekolah;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Cache;
use App\Http\Resources\ProfilSekolahResource;
use App\Http\Resources\ProfilSekolahCollection;

class ProfilSekolahController extends Controller
{
    // Aturan validasi untuk store dan update
    protected $validationRules = [
        'kapita_id' => 'required|exists:jml_kapita_sekolah,id',
        'fasilitas_id' => 'required|exists:fasilitas_sekolah,id',
        'nama_sekolah' => 'required|string|max:100|unique:profil_sekolah',
        'NPSN' => 'required|string|size:8|unique:profil_sekolah',
        'alamat' => 'required|string',
        'kecamatan' => 'required|string|max:25',
        'jenjang_id' => 'required|exists:jenjang_sekolah,id',
        'no_telepon' => 'required|string|max:15|unique:profil_sekolah',
        'email' => 'nullable|string|email|max:50|unique:profil_sekolah',
        'link_website' => 'nullable|string|max:255',
        'nama_kontak_person' => 'required|string|max:30',
        'jabatan' => 'required|string|max:25',
    ];

    // Tampilkan daftar profil sekolah dengan pagination dan caching
    public function index(Request $request)
    {
        $page = $request->input('page', 1); // Mendapatkan nomor halaman dari query string, default 1
        $perPage = $request->input('per_page', 10); // Jumlah item per halaman, default 10

        $cacheKey = "profilSekolah_page_{$page}_perPage_{$perPage}";

        $profilSekolah = Cache::remember($cacheKey, 60 * 60, function () use ($page, $perPage) {
            return ProfilSekolah::with(['kapita', 'fasilitas', 'jenjang'])
                ->paginate($perPage, ['*'], 'page', $page);
        });

        return new ProfilSekolahCollection($profilSekolah);
    }

    // Tambahkan profil sekolah baru
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), $this->validationRules);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $profilSekolah = ProfilSekolah::create($validator->validated());

        // Hapus cache untuk semua halaman
        Cache::tags('profilSekolah')->flush();

        return new ProfilSekolahResource($profilSekolah, 201);
    }

    // Tampilkan profil sekolah berdasarkan ID
    public function show($id)
    {
        $profilSekolah = ProfilSekolah::with(['kapita', 'fasilitas', 'jenjang'])->find($id);

        if (!$profilSekolah) {
            return response()->json(['message' => 'Data tidak ditemukan'], 404);
        }

        return new ProfilSekolahResource($profilSekolah);
    }

    // Update profil sekolah
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), array_merge(
            $this->validationRules,
            [
                'nama_sekolah' => 'required|string|max:100|unique:profil_sekolah,nama_sekolah,' . $id,
                'NPSN' => 'required|string|size:8|unique:profil_sekolah,NPSN,' . $id,
                'no_telepon' => 'required|string|max:15|unique:profil_sekolah,no_telepon,' . $id,
                'email' => 'nullable|string|email|max:50|unique:profil_sekolah,email,' . $id,
            ]
        ));

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $profilSekolah = ProfilSekolah::find($id);

        if (!$profilSekolah) {
            return response()->json(['message' => 'Data tidak ditemukan'], 404);
        }

        $profilSekolah->update($validator->validated());

        // Hapus cache untuk semua halaman
        Cache::tags('profilSekolah')->flush();

        return new ProfilSekolahResource($profilSekolah);
    }

    // Hapus profil sekolah
    public function destroy($id)
    {
        $profilSekolah = ProfilSekolah::find($id);

        if (!$profilSekolah) {
            return response()->json(['message' => 'Data tidak ditemukan'], 404);
        }

        $profilSekolah->delete();

        // Hapus cache untuk semua halaman
        Cache::tags('profilSekolah')->flush();

        return response()->json(['message' => 'Profil sekolah berhasil dihapus'], 200);
    }
}
