<?php

namespace App\Http\Controllers;

use App\Models\Dokumen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class DokumenController extends Controller
{
    public function index()
    {
        $dokumen = Dokumen::all();
        return response()->json($dokumen);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            // Add your validation rules here

            'nama_panduan' => 'required|string|max:255',
            'deskripsi' => 'string',
            'jenis_dokumen_id' => 'required|exists:jenis_dokumen,id',

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $dokumen = Dokumen::create($request->all());
        return response()->json($dokumen, 201);
    }

    public function update(Request $request, $id)
    {
        // Validate the request
        $validator = Validator::make($request->all(), [
            'nama_panduan' => 'required|string|max:255',
            'deskripsi' => 'string',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Find the document
        $dokumen = Dokumen::find($id);

        if (!$dokumen) {
            return response()->json(['message' => 'Document not found'], 404);
        }

        // Sanitize input
        $input = $request->only(['nama_panduan', 'deskripsi']);
        $input = array_map('strip_tags', $input);

        // Update the document
        $dokumen->update($input);

        return response()->json($dokumen, 200);
    }
    public function show($id)
    {
        $dokumen = Dokumen::find($id);

        if (!$dokumen) {
            return response()->json(['message' => 'Document not found'], 404);
        }

        return response()->json($dokumen);
    }

    public function destroy($id)
    {
        Dokumen::destroy($id);
        return response()->json(null, 204);
    }
}
