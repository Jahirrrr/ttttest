<?php

namespace App\Http\Controllers;

use App\Models\JenjangSekolah;
use Illuminate\Http\Request;

class JenjangSekolahController extends Controller
{
    public function index()
    {
        $jenjangSekolah = JenjangSekolah::all();
        return response()->json($jenjangSekolah);
    }
}
