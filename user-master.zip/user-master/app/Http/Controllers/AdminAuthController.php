<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\Admin;
use Illuminate\Validation\ValidationException;

class AdminAuthController extends Controller
{
    // Fungsi login admin
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::guard('admin')->attempt($credentials)) {
            $request->session()->regenerate();
            return response()->json(['message' => 'Login successful']);
        }

        return response()->json(['error' => 'Invalid credentials'], 401);
    }

    // Fungsi logout admin
    public function logout(Request $request)
    {
        Auth::guard('admin')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return response()->json(['message' => 'Logout successful']);
    }

    // Fungsi register admin
    public function register(Request $request)
    {
        try {
            // Validasi input
            $data = $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:admins,email',
                'password' => 'required|string|min:8',
            ]);

            // Buat admin baru
            $admin = Admin::create([
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => Hash::make($data['password']),
            ]);

            // Login admin setelah registrasi
            Auth::guard('admin')->login($admin);

            return response()->json(['message' => 'Registration successful']);
        } catch (ValidationException $e) {
            // Tampilkan pesan error kustom
            return response()->json(['errors' => $e->errors()], 422);
        } catch (\Exception $e) {
            // Tangani error lain yang mungkin terjadi
            return response()->json(['error' => 'An error occurred during registration. Please try again later.'], 500);
        }
    }
}
