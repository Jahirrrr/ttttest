<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProfilSekolahSeeder extends Seeder
{
    public function run()
    {
        DB::table('profil_sekolah')->insert([
            [
                'kapita_id' => 1, // Pastikan id ini sudah ada di tabel jml_kapita_sekolah
                'fasilitas_id' => 1, // Pastikan id ini sudah ada di tabel fasilitas_sekolah
                'nama_sekolah' => 'SD Negeri Contoh',
                'NPSN' => '12345678',
                'alamat' => 'Jl. Contoh No. 1, Kota Contoh',
                'kecamatan' => 'Kecamatan Contoh',
                'jenjang_id' => 1, // Pastikan id ini sudah ada di tabel jenjang_sekolah
                'no_telepon' => '08123456789',
                'email' => 'sdnegeri@example.com',
                'link_website' => 'http://sdnegeri.example.com',
                'nama_kontak_person' => 'Bapak Contoh',
                'jabatan' => 'Kepala Sekolah',
            ],
        ]);
    }
}
