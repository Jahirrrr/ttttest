<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Informasi;

class InformasiSeeder extends Seeder
{
    public function run()
    {
        $informasi = [
            [
                'jenis_id' => 1, // Sesuai ID dari jenis_informasi
                'gambar' => 'path/to/image1.jpg',
                'judul' => 'Berita Terbaru',
                'body' => 'Ini adalah berita terbaru.',
            ],
            [
                'jenis_id' => 2, // Sesuai ID dari jenis_informasi
                'gambar' => 'path/to/image2.jpg',
                'judul' => 'Pengumuman Penting',
                'body' => 'Ini adalah pengumuman penting.',
            ],
        ];

        foreach ($informasi as $info) {
            Informasi::create($info);
        }
    }
}
