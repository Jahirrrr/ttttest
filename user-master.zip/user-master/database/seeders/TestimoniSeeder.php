<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Testimoni;

class TestimoniSeeder extends Seeder
{
    public function run()
    {
        $testimoni = [
            [
                'nama_testimoni' => 'John Doe',
                'body' => 'Ini adalah testimoni dari John Doe.',
            ],
            [
                'nama_testimoni' => 'Jane Smith',
                'body' => 'Ini adalah testimoni dari Jane Smith.',
            ],
        ];

        foreach ($testimoni as $test) {
            Testimoni::create($test);
        }
    }
}
